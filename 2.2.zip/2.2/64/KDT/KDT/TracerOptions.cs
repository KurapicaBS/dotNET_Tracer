﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KDT
{
    public class TracerOptions
    {

        //====================================================================

        //private bool p_AssemblyLoaded_log;
        //public bool AssemblyLoadedLog
        //{
        //    get { return p_AssemblyLoaded_log; }
        //    set { p_AssemblyLoaded_log = value; }
        //}

        //private bool p_AssemblyLoaded_break;
        //public bool AssemblyLoadedBreak
        //{
        //    get { return p_AssemblyLoaded_break; }
        //    set { p_AssemblyLoaded_break = value; }
        //}


        //====================================================================

        private bool p_ModuleLoaded_log;
        public bool ModuleLoadedLog
        {
            get { return p_ModuleLoaded_log; }
            set { p_ModuleLoaded_log = value; }
        }

        private bool p_ModuleLoaded_break;
        public bool ModuleLoadedBreak
        {
            get { return p_ModuleLoaded_break; }
            set { p_ModuleLoaded_break = value; }
        }

        //====================================================================

        private bool p_EnterFunction_log;
        public bool EnterFunctionLog
        {
            get { return p_EnterFunction_log; }
            set { p_EnterFunction_log = value; }
        }

        private bool p_EnterFunction_break;
        public bool EnterFunctionBreak
        {
            get { return p_EnterFunction_break; }
            set { p_EnterFunction_break = value; }
        }

        //====================================================================

        private bool p_ExceptionThrown_log;
        public bool ExceptionThrownLog
        {
            get { return p_ExceptionThrown_log; }
            set { p_ExceptionThrown_log = value; }
        }

        private bool p_ExceptionThrown_break;
        public bool ExceptionThrownBreak
        {
            get { return p_ExceptionThrown_break; }
            set { p_ExceptionThrown_break = value; }
        }


        //====================================================================

        private bool p_ThreadCreated_log;
        public bool ThreadCreatedLog
        {
            get { return p_ThreadCreated_log; }
            set { p_ThreadCreated_log = value; }
        }

        private bool p_ThreadCreated_break;
        public bool ThreadCreatedBreak
        {
            get { return p_ThreadCreated_break; }
            set { p_ThreadCreated_break = value; }
        }

        //====================================================================

        private bool p_ThreadDestroyed_log;
        public bool ThreadDestroyedLog
        {
            get { return p_ThreadDestroyed_log; }
            set { p_ThreadDestroyed_log = value; }
        }

        private bool p_ThreadDestroyed_break;
        public bool ThreadDestroyedBreak
        {
            get { return p_ThreadDestroyed_break; }
            set { p_ThreadDestroyed_break = value; }
        }


        //=====================================================================

        private bool p_Active;
        public bool Power
        {
            get { return p_Active; }
            set { p_Active = value; }
        }

    }
}
