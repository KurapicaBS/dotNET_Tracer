﻿namespace KDT
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Main));
            this.toolStrip_main = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_Restart = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_Stop = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_resume = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_pause = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_Clear = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_Save = new System.Windows.Forms.ToolStripDropDownButton();
            this.ToolStripMenuItem_Save_as_Text = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Save_as_excel = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.checkBox_ModuleLoaded_Log = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.checkBox_EnterFunction_Log = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBox_exceptionThrown_Log = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.checkBox_threadCreated_Log = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.checkBox_ModuleLoaded_break = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.checkBox_EnterFunction_break = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBox_exceptionThrown_break = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.checkBox_threadCreated_break = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_About = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_autoScroll = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_power = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox_FileName = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripButton_browse = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox_args = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_start = new System.Windows.Forms.ToolStripButton();
            this.Grid = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.toolStrip_main.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip_main
            // 
            this.toolStrip_main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_Restart,
            this.toolStripButton_Stop,
            this.toolStripSeparator1,
            this.toolStripButton_resume,
            this.toolStripButton_pause,
            this.toolStripSeparator2,
            this.toolStripButton_Clear,
            this.toolStripButton_Save,
            this.toolStripSeparator3,
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton2,
            this.toolStripSeparator10,
            this.toolStripButton_About,
            this.toolStripButton_autoScroll,
            this.toolStripButton_power});
            this.toolStrip_main.Location = new System.Drawing.Point(0, 0);
            this.toolStrip_main.Name = "toolStrip_main";
            this.toolStrip_main.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip_main.Size = new System.Drawing.Size(1075, 25);
            this.toolStrip_main.TabIndex = 1;
            this.toolStrip_main.Text = "toolStrip1";
            // 
            // toolStripButton_Restart
            // 
            this.toolStripButton_Restart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_Restart.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_Restart.Image")));
            this.toolStripButton_Restart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Restart.Name = "toolStripButton_Restart";
            this.toolStripButton_Restart.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_Restart.Text = "Restart";
            this.toolStripButton_Restart.Click += new System.EventHandler(this.toolStripButton_Restart_Click);
            // 
            // toolStripButton_Stop
            // 
            this.toolStripButton_Stop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_Stop.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_Stop.Image")));
            this.toolStripButton_Stop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Stop.Name = "toolStripButton_Stop";
            this.toolStripButton_Stop.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_Stop.Text = "Stop tracing and terminate process";
            this.toolStripButton_Stop.Click += new System.EventHandler(this.toolStripButton_Stop_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton_resume
            // 
            this.toolStripButton_resume.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_resume.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_resume.Image")));
            this.toolStripButton_resume.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_resume.Name = "toolStripButton_resume";
            this.toolStripButton_resume.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_resume.Text = "Resume";
            this.toolStripButton_resume.Click += new System.EventHandler(this.toolStripButton_resume_Click);
            // 
            // toolStripButton_pause
            // 
            this.toolStripButton_pause.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_pause.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_pause.Image")));
            this.toolStripButton_pause.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_pause.Name = "toolStripButton_pause";
            this.toolStripButton_pause.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_pause.Text = "Suspend process";
            this.toolStripButton_pause.Click += new System.EventHandler(this.toolStripButton_pause_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton_Clear
            // 
            this.toolStripButton_Clear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_Clear.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_Clear.Image")));
            this.toolStripButton_Clear.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Clear.Name = "toolStripButton_Clear";
            this.toolStripButton_Clear.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_Clear.Text = "Clear results";
            this.toolStripButton_Clear.Click += new System.EventHandler(this.toolStripButton_Clear_Click);
            // 
            // toolStripButton_Save
            // 
            this.toolStripButton_Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_Save.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Save_as_Text,
            this.ToolStripMenuItem_Save_as_excel});
            this.toolStripButton_Save.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_Save.Image")));
            this.toolStripButton_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Save.Name = "toolStripButton_Save";
            this.toolStripButton_Save.Size = new System.Drawing.Size(29, 22);
            this.toolStripButton_Save.Text = "Save results";
            this.toolStripButton_Save.Click += new System.EventHandler(this.toolStripButton_Save_Click);
            // 
            // ToolStripMenuItem_Save_as_Text
            // 
            this.ToolStripMenuItem_Save_as_Text.Name = "ToolStripMenuItem_Save_as_Text";
            this.ToolStripMenuItem_Save_as_Text.Size = new System.Drawing.Size(195, 22);
            this.ToolStripMenuItem_Save_as_Text.Text = "Text file";
            this.ToolStripMenuItem_Save_as_Text.Click += new System.EventHandler(this.textFileToolStripMenuItem_Save_as_Text_Click);
            // 
            // ToolStripMenuItem_Save_as_excel
            // 
            this.ToolStripMenuItem_Save_as_excel.Name = "ToolStripMenuItem_Save_as_excel";
            this.ToolStripMenuItem_Save_as_excel.Size = new System.Drawing.Size(195, 22);
            this.ToolStripMenuItem_Save_as_excel.Text = "Microsoft Excel file";
            this.ToolStripMenuItem_Save_as_excel.Click += new System.EventHandler(this.ToolStripMenuItem_Save_as_excel_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.checkBox_ModuleLoaded_Log,
            this.toolStripSeparator4,
            this.checkBox_EnterFunction_Log,
            this.checkBox_exceptionThrown_Log,
            this.toolStripSeparator5,
            this.checkBox_threadCreated_Log});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(134, 22);
            this.toolStripDropDownButton1.Text = "Log these events";
            // 
            // checkBox_ModuleLoaded_Log
            // 
            this.checkBox_ModuleLoaded_Log.Checked = true;
            this.checkBox_ModuleLoaded_Log.CheckOnClick = true;
            this.checkBox_ModuleLoaded_Log.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_ModuleLoaded_Log.Name = "checkBox_ModuleLoaded_Log";
            this.checkBox_ModuleLoaded_Log.Size = new System.Drawing.Size(145, 22);
            this.checkBox_ModuleLoaded_Log.Text = "Modules";
            this.checkBox_ModuleLoaded_Log.Click += new System.EventHandler(this.checkBox_ModuleLoaded_Log_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(142, 6);
            // 
            // checkBox_EnterFunction_Log
            // 
            this.checkBox_EnterFunction_Log.Checked = true;
            this.checkBox_EnterFunction_Log.CheckOnClick = true;
            this.checkBox_EnterFunction_Log.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_EnterFunction_Log.Name = "checkBox_EnterFunction_Log";
            this.checkBox_EnterFunction_Log.Size = new System.Drawing.Size(145, 22);
            this.checkBox_EnterFunction_Log.Text = "Functions";
            this.checkBox_EnterFunction_Log.Click += new System.EventHandler(this.checkBox_EnterFunction_Log_Click);
            // 
            // checkBox_exceptionThrown_Log
            // 
            this.checkBox_exceptionThrown_Log.Checked = true;
            this.checkBox_exceptionThrown_Log.CheckOnClick = true;
            this.checkBox_exceptionThrown_Log.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_exceptionThrown_Log.Name = "checkBox_exceptionThrown_Log";
            this.checkBox_exceptionThrown_Log.Size = new System.Drawing.Size(145, 22);
            this.checkBox_exceptionThrown_Log.Text = "Exceptions";
            this.checkBox_exceptionThrown_Log.Click += new System.EventHandler(this.checkBox_exceptionThrown_Log_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(142, 6);
            // 
            // checkBox_threadCreated_Log
            // 
            this.checkBox_threadCreated_Log.CheckOnClick = true;
            this.checkBox_threadCreated_Log.Name = "checkBox_threadCreated_Log";
            this.checkBox_threadCreated_Log.Size = new System.Drawing.Size(145, 22);
            this.checkBox_threadCreated_Log.Text = "Threads";
            this.checkBox_threadCreated_Log.Click += new System.EventHandler(this.checkBox_threadCreated_Log_Click);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.checkBox_ModuleLoaded_break,
            this.toolStripSeparator6,
            this.checkBox_EnterFunction_break,
            this.checkBox_exceptionThrown_break,
            this.toolStripSeparator7,
            this.checkBox_threadCreated_break});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(79, 22);
            this.toolStripDropDownButton2.Text = "Break on";
            // 
            // checkBox_ModuleLoaded_break
            // 
            this.checkBox_ModuleLoaded_break.CheckOnClick = true;
            this.checkBox_ModuleLoaded_break.Name = "checkBox_ModuleLoaded_break";
            this.checkBox_ModuleLoaded_break.Size = new System.Drawing.Size(187, 22);
            this.checkBox_ModuleLoaded_break.Text = "Module events";
            this.checkBox_ModuleLoaded_break.Click += new System.EventHandler(this.checkBox_ModuleLoaded_break_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(184, 6);
            // 
            // checkBox_EnterFunction_break
            // 
            this.checkBox_EnterFunction_break.CheckOnClick = true;
            this.checkBox_EnterFunction_break.Name = "checkBox_EnterFunction_break";
            this.checkBox_EnterFunction_break.Size = new System.Drawing.Size(187, 22);
            this.checkBox_EnterFunction_break.Text = "Function called";
            this.checkBox_EnterFunction_break.Click += new System.EventHandler(this.checkBox_EnterFunction_break_Click);
            // 
            // checkBox_exceptionThrown_break
            // 
            this.checkBox_exceptionThrown_break.CheckOnClick = true;
            this.checkBox_exceptionThrown_break.Name = "checkBox_exceptionThrown_break";
            this.checkBox_exceptionThrown_break.Size = new System.Drawing.Size(187, 22);
            this.checkBox_exceptionThrown_break.Text = "Exception thrown";
            this.checkBox_exceptionThrown_break.Click += new System.EventHandler(this.checkBox_exceptionThrown_break_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(184, 6);
            // 
            // checkBox_threadCreated_break
            // 
            this.checkBox_threadCreated_break.CheckOnClick = true;
            this.checkBox_threadCreated_break.Name = "checkBox_threadCreated_break";
            this.checkBox_threadCreated_break.Size = new System.Drawing.Size(187, 22);
            this.checkBox_threadCreated_break.Text = "Thread events";
            this.checkBox_threadCreated_break.Click += new System.EventHandler(this.checkBox_threadCreated_break_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton_About
            // 
            this.toolStripButton_About.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton_About.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_About.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_About.Image")));
            this.toolStripButton_About.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_About.Name = "toolStripButton_About";
            this.toolStripButton_About.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_About.Text = "About this...";
            this.toolStripButton_About.Click += new System.EventHandler(this.toolStripButton_About_Click);
            // 
            // toolStripButton_autoScroll
            // 
            this.toolStripButton_autoScroll.Checked = true;
            this.toolStripButton_autoScroll.CheckOnClick = true;
            this.toolStripButton_autoScroll.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton_autoScroll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_autoScroll.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_autoScroll.Image")));
            this.toolStripButton_autoScroll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_autoScroll.Name = "toolStripButton_autoScroll";
            this.toolStripButton_autoScroll.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_autoScroll.Text = "Auto scroll";
            // 
            // toolStripButton_power
            // 
            this.toolStripButton_power.Checked = true;
            this.toolStripButton_power.CheckOnClick = true;
            this.toolStripButton_power.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton_power.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_power.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_power.Image")));
            this.toolStripButton_power.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_power.Name = "toolStripButton_power";
            this.toolStripButton_power.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_power.Text = "Toggle tracing ON/OFF";
            this.toolStripButton_power.Click += new System.EventHandler(this.toolStripButton_power_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.AllowDrop = true;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripTextBox_FileName,
            this.toolStripButton_browse,
            this.toolStripSeparator8,
            this.toolStripLabel2,
            this.toolStripTextBox_args,
            this.toolStripSeparator9,
            this.toolStripButton_start});
            this.toolStrip1.Location = new System.Drawing.Point(0, 25);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(1075, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.DragDrop += new System.Windows.Forms.DragEventHandler(this.toolStrip1_DragDrop);
            this.toolStrip1.DragEnter += new System.Windows.Forms.DragEventHandler(this.toolStrip1_DragEnter);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(91, 22);
            this.toolStripLabel1.Text = "File location :";
            // 
            // toolStripTextBox_FileName
            // 
            this.toolStripTextBox_FileName.Name = "toolStripTextBox_FileName";
            this.toolStripTextBox_FileName.Size = new System.Drawing.Size(400, 25);
            this.toolStripTextBox_FileName.ToolTipText = "Executable file to trace";
            // 
            // toolStripButton_browse
            // 
            this.toolStripButton_browse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_browse.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_browse.Image")));
            this.toolStripButton_browse.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_browse.Name = "toolStripButton_browse";
            this.toolStripButton_browse.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_browse.Text = "Select file";
            this.toolStripButton_browse.Click += new System.EventHandler(this.toolStripButton_browse_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(89, 22);
            this.toolStripLabel2.Text = "Arguments :";
            // 
            // toolStripTextBox_args
            // 
            this.toolStripTextBox_args.Name = "toolStripTextBox_args";
            this.toolStripTextBox_args.Size = new System.Drawing.Size(249, 25);
            this.toolStripTextBox_args.ToolTipText = "Arguments for this process";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton_start
            // 
            this.toolStripButton_start.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_start.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_start.Image")));
            this.toolStripButton_start.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_start.Name = "toolStripButton_start";
            this.toolStripButton_start.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton_start.Text = "toolStripButton1";
            this.toolStripButton_start.ToolTipText = "Start tracing...";
            this.toolStripButton_start.Click += new System.EventHandler(this.toolStripButton_start_Click);
            // 
            // Grid
            // 
            this.Grid.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.Grid.AutoGenerateColumns = false;
            this.Grid.ColumnInfo = resources.GetString("Grid.ColumnInfo");
            this.Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Grid.ExtendLastCol = true;
            this.Grid.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.Heavy;
            this.Grid.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Grid.Location = new System.Drawing.Point(0, 50);
            this.Grid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Grid.Name = "Grid";
            this.Grid.Rows.Count = 1;
            this.Grid.Rows.DefaultSize = 25;
            this.Grid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.Grid.ShowSortPosition = C1.Win.C1FlexGrid.ShowSortPositionEnum.None;
            this.Grid.Size = new System.Drawing.Size(1075, 525);
            this.Grid.StyleInfo = resources.GetString("Grid.StyleInfo");
            this.Grid.TabIndex = 3;
            this.Grid.Tree.Column = 1;
            this.Grid.Tree.Style = C1.Win.C1FlexGrid.TreeStyleFlags.Lines;
            this.Grid.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.Office2010Silver;
            this.Grid.GridChanged += new C1.Win.C1FlexGrid.GridChangedEventHandler(this.Grid_GridChanged);
            this.Grid.DoubleClick += new System.EventHandler(this.Grid_DoubleClick);
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1075, 575);
            this.Controls.Add(this.Grid);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.toolStrip_main);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dotNET Tracer v2.2 - x64";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Main_FormClosing);
            this.Load += new System.EventHandler(this.Form_Main_Load);
            this.toolStrip_main.ResumeLayout(false);
            this.toolStrip_main.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip_main;
        private System.Windows.Forms.ToolStripButton toolStripButton_Restart;
        private System.Windows.Forms.ToolStripButton toolStripButton_Stop;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton_resume;
        private System.Windows.Forms.ToolStripButton toolStripButton_pause;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton_Clear;
        private System.Windows.Forms.ToolStripButton toolStripButton_autoScroll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem checkBox_ModuleLoaded_Log;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem checkBox_EnterFunction_Log;
        private System.Windows.Forms.ToolStripMenuItem checkBox_exceptionThrown_Log;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem checkBox_threadCreated_Log;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem checkBox_ModuleLoaded_break;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem checkBox_EnterFunction_break;
        private System.Windows.Forms.ToolStripMenuItem checkBox_exceptionThrown_break;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem checkBox_threadCreated_break;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox_FileName;
        private System.Windows.Forms.ToolStripButton toolStripButton_browse;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox_args;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton toolStripButton_start;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripButton toolStripButton_About;
        private C1.Win.C1FlexGrid.C1FlexGrid Grid;
        private System.Windows.Forms.ToolStripButton toolStripButton_power;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton_Save;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Save_as_Text;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Save_as_excel;


    }
}

