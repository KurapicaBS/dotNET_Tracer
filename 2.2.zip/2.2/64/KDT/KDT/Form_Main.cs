﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;


namespace KDT
{
    public partial class Form_Main : Form
    {
        public Form_Main()
        {
            InitializeComponent();
        }

        //Entrypoint
        private void Form_Main_Load(object sender, EventArgs e)
        {


            if (HookME() == false)
            {

                MessageBox.Show("Can't hook main window !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();

            }

            PrimaryRowFont = new Font(Grid.Font, FontStyle.Bold);

        }

        //Endpoint
        private void Form_Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            UnHookME();
        }

        //Select assembly to trace
        private void toolStripButton_browse_Click(object sender, EventArgs e)
        {

            using (OpenFileDialog CD = new OpenFileDialog())
            {
                CD.Filter = ".NET Assembly|*.exe";
                CD.CheckFileExists = true;
                CD.FilterIndex = 0;
                CD.ShowReadOnly = false;
                CD.ShowHelp = false;
                CD.Title = "Select assembly to dump";
                UnHookME();
                if (CD.ShowDialog() == DialogResult.OK)
                {
                    this.toolStripTextBox_FileName.Text = CD.FileName;
                }
                HookME();
            }


        }

        //Start tracing
        private void toolStripButton_start_Click(object sender, EventArgs e)
        {

            try
            {
                if (!File.Exists(this.toolStripTextBox_FileName.Text))
                {
                    MessageBox.Show("Select an executable assembly file first !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (!RegisterEngineDLL())
                    {
                        Application.Exit();
                    }


                    ProcessStartInfo ProcessSInfo = new ProcessStartInfo(this.toolStripTextBox_FileName.Text, this.toolStripTextBox_args.Text);
                    ProcessSInfo.EnvironmentVariables.Add("COR_ENABLE_PROFILING", "1");
                    ProcessSInfo.EnvironmentVariables.Add("COR_PROFILER", "{7A460847-6B67-4C0C-883E-21B233A6DEF8}");
                    ProcessSInfo.EnvironmentVariables.Add("COMPLUS_ProfAPI_ProfilerCompatibilitySetting", "EnableV2Profiler");
                    ProcessSInfo.EnvironmentVariables.Add("LoaderHwnd", this.Handle.ToInt32().ToString());


                    Application.DoEvents();
                    ProcessSInfo.UseShellExecute = false;
                    this.CurrentProcess = Process.Start(ProcessSInfo);

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }


        public bool RegisterEngineDLL()
        {
            if (!this.EngineDLLregistered)
            {
                if (Win32APIs.DllRegisterServer() != 0)
                {
                    MessageBox.Show("Couldn't start tracing engine !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    EngineDLLregistered = false;
                }
                EngineDLLregistered = true;
            }
            return EngineDLLregistered;
        }


        //Clear grid contents
        private void toolStripButton_Clear_Click(object sender, EventArgs e)
        {

            Grid.Rows.Count = 1;

        }



        #region Properties

        //Current Active Tracer
        private Tracer p_Tracer;
        public Tracer Tracer
        {
            get { return p_Tracer; }
            set { p_Tracer = value; }
        }


        private bool p_EngineDLLregistered = false;
        public bool EngineDLLregistered
        {
            get { return p_EngineDLLregistered; }
            set
            { p_EngineDLLregistered = value; }
        }

        private Process p_CurrentProcess;
        public Process CurrentProcess
        {
            get { return p_CurrentProcess; }
            set
            {

                if (p_CurrentProcess != null)
                {
                    p_CurrentProcess.Close();
                }

                p_CurrentProcess = value;
            }

        }

        private Font PrimaryRowFont;

        #endregion


        #region Hooking

        static readonly int GWL_WNDPROC = -4;

        //hooking flag
        private bool p_IsHooked = false;
        public bool IsHooked
        {
            get { return p_IsHooked; }
            set { p_IsHooked = value; }
        }

        //new Window procedure
        private KDT.Win32APIs.WindowProcedure NewWindProcedure;

        //old Window procedure
        private IntPtr PrevWindProcedure;

        //called on application startup
        private bool HookME()
        {

            //Hook this window
            try
            {
                //Create a new Window procedure
                this.NewWindProcedure = new KDT.Win32APIs.WindowProcedure(this.HookedWindowProc);

                //Set Main window procedure to the new one
                this.PrevWindProcedure = new IntPtr(Win32APIs.SetWindowLongPtr(this.Handle, GWL_WNDPROC, this.NewWindProcedure));

                //set flag
                this.IsHooked = (this.PrevWindProcedure != IntPtr.Zero) ? true : false;

                return IsHooked;

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Initialization Error !", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        }

        //called on app end
        private void UnHookME()
        {

            //Hook this window
            try
            {
                int ret = 0;

                ret = Win32APIs.SetWindowLongEX(this.Handle, GWL_WNDPROC, this.PrevWindProcedure);

                this.IsHooked = (ret != 0);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error !", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }


        #endregion


        #region Received Data



        private const int WM_COPYDATA = 74;

        private const int WM_USER = 1024;

        private const int CM_AppDomainCreationFinished = 1029;
        private const int CM_AppDomainCreationStarted = 1030;
        private const int CM_AppDomainShutdownFinished = 1032;
        private const int CM_AppDomainShutdownStarted = 1031;
        private const int CM_AssemblyLoadFinished = 1033;
        private const int CM_AssemblyLoadStarted = 1034;
        private const int CM_AssemblyUnloadFinished = 1035;
        private const int CM_AssemblyUnloadStarted = 1036;
        private const int CM_ClassLoadFinished = 1042;
        private const int CM_ClassLoadStarted = 1043;
        private const int CM_ClassUnloadFinished = 1044;
        private const int CM_ClassUnloadStarted = 1045;
        private const int CM_COMClassicVTableCreated = 1068;
        private const int CM_COMClassicVTableDestroyed = 1069;
        private const int CM_ExceptionCatcherEnter = 1070;
        private const int CM_ExceptionCatcherLeave = 1071;
        private const int CM_ExceptionCLRCatcherExecute = 1072;
        private const int CM_ExceptionCLRCatcherFound = 1073;
        private const int CM_ExceptionSearchCatcherFound = 1074;
        private const int CM_ExceptionSearchFilterEnter = 1075;
        private const int CM_ExceptionSearchFilterLeave = 1076;
        private const int CM_ExceptionSearchFunctionEnter = 1077;
        private const int CM_ExceptionSearchFunctionLeave = 1078;
        private const int CM_ExceptionThrown = 1079;
        private const int CM_ExceptionUnwindFinallyEnter = 1080;
        private const int CM_ExceptionUnwindFinallyLeave = 1081;
        private const int CM_ExceptionUnwindFunctionEnter = 1082;
        private const int CM_ExceptionUnwindFunctionLeave = 1083;
        private const int CM_JITCachedFunctionSearchFinished = 1050;
        private const int CM_JITCachedFunctionSearchStarted = 1051;
        private const int CM_JITCompilationFinished = 1046;
        private const int CM_JITCompilationStarted = 1047;
        private const int CM_JITFunctionPitched = 1049;
        private const int CM_ModuleAttachedToAssembly = 1037;
        private const int CM_ModuleLoadFinished = 1038;
        private const int CM_ModuleLoadStarted = 1039;
        private const int CM_ModuleUnloadFinished = 1040;
        private const int CM_ModuleUnloadStarted = 1041;
        private const int CM_ProfilerExiting = 1027;
        private const int CM_ProfilerStarted = 1028;
        private const int CM_RuntimeResumeFinished = 1055;
        private const int CM_RuntimeResumeStarted = 1056;
        private const int CM_RuntimeSuspendAborted = 1057;
        private const int CM_RuntimeSuspendFinished = 1058;
        private const int CM_RuntimeSuspendStarted = 1059;
        private const int CM_RuntimeThreadResumed = 1060;
        private const int CM_RuntimeThreadSuspended = 1061;
        private const int CM_ThreadAssignedToOSThread = 1052;
        private const int CM_ThreadCreated = 1053;
        private const int CM_ThreadDestroyed = 1054;

        [StructLayout(LayoutKind.Sequential)]
        private struct tagCOPYDATASTRUCT
        {
            [MarshalAs(UnmanagedType.U8)]
            public UInt64 dwData;
            [MarshalAs(UnmanagedType.U4)]
            public UInt32 cbData;
            [MarshalAs(UnmanagedType.U8)]
            public long lpData;
        }

        public int HookedWindowProc(IntPtr hwnd, int uMsg, int wParam, int lParam)
        {


            switch (uMsg)
            {

                case WM_COPYDATA:
                    {


                        //test if logging is on
                        if (this.Tracer != null)
                        {
                            if (this.Tracer.TracingOptions.Power == false)
                            {
                                return Win32APIs.CallWindowProc(this.PrevWindProcedure, hwnd, (uint)uMsg, wParam, lParam);
                            }
                        }

                        IntPtr tracingMsg = new IntPtr(lParam);
                        tagCOPYDATASTRUCT DT = (tagCOPYDATASTRUCT)Marshal.PtrToStructure(tracingMsg, typeof(tagCOPYDATASTRUCT));

                        ProcessMessage(Marshal.PtrToStringUni(new IntPtr(DT.lpData)), (int)DT.dwData);

                        break;
                    }


                case CM_ProfilerExiting:
                    {

                        //add last event
                        Grid.Rows.Add();
                        Grid.SetData(Grid.Rows.Count - 1, 1, "Tracing ended successfully [" + DateTime.Now.ToString() + "]");
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        Grid.Rows[Grid.Rows.Count - 1].Node.Level = -1;



                        //enable about button
                        this.toolStripButton_About.Enabled = true;

                        //enable save button
                        this.toolStripButton_Save.Enabled = true;

                        //enable start button
                        this.toolStrip1.Enabled = true;

                        break;
                    }


                case CM_ProfilerStarted:
                    {

                        //prepare options
                        TracerOptions options = new TracerOptions();

                        //options.AssemblyLoadedBreak = checkBox_AssemblyLoaded_break.Checked;
                        //options.AssemblyLoadedLog = checkBox_AssemblyLoaded_log.Checked;

                        options.EnterFunctionBreak = checkBox_EnterFunction_break.Checked;
                        options.EnterFunctionLog = checkBox_EnterFunction_Log.Checked;

                        options.ExceptionThrownBreak = checkBox_exceptionThrown_break.Checked;
                        options.ExceptionThrownLog = checkBox_exceptionThrown_Log.Checked;

                        options.ModuleLoadedBreak = checkBox_ModuleLoaded_break.Checked;
                        options.ModuleLoadedLog = checkBox_ModuleLoaded_Log.Checked;

                        options.ThreadCreatedBreak = checkBox_threadCreated_break.Checked;
                        options.ThreadCreatedLog = checkBox_threadCreated_Log.Checked;

                        options.Power = toolStripButton_power.Checked;

                        //options.ThreadDestroyedBreak = checkBox_thread_destroyed_break.Checked;
                        //options.ThreadDestroyedLog = checkBox_thread_destroyed_Log.Checked;

                        this.Tracer = new Tracer(toolStripTextBox_FileName.Text, toolStripTextBox_args.Text, options);

                        //disable about button
                        this.toolStripButton_About.Enabled = false;

                        //disable save button
                        this.toolStripButton_Save.Enabled = false;

                        //disable start button
                        this.toolStrip1.Enabled = false;


                        //clear old results
                        this.Grid.Rows.Count = 1;

                        //add first event
                        Grid.Rows.Add();
                        Grid.SetData(1, 1, "Tracing started [" + DateTime.Now.ToString() + "]");
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = false;


                        break;
                    }

            }

            //Console.WriteLine(wParam.ToString());

            return Win32APIs.CallWindowProc(this.PrevWindProcedure, hwnd, (uint)uMsg, wParam, lParam);


        }

        private enum RowType
        {
            ModuleRow,
            MethodRow,
            TypeRow
        }

        private struct ExtraRowTag
        {
            public RowType RowType;
            public string ModulePath;
            public string MethodPath;
            public string TypePath;
        }

        private void ProcessMessage(string msg, int MsgType)
        {


            //string msgbody = System.Text.Encoding.Unicode.GetString( Convert.FromBase64String(msg));
            System.Xml.XmlReaderSettings settings = new System.Xml.XmlReaderSettings();
            settings.CheckCharacters = false;
            settings.IgnoreWhitespace = true;


            System.Xml.XmlReader xml = System.Xml.XmlReader.Create(new StringReader(msg), settings);

            switch (MsgType)
            {



                case CM_ModuleLoadStarted:
                case CM_ModuleUnloadStarted:
                    {


                        if (!this.Tracer.TracingOptions.ModuleLoadedLog)
                        {
                            return;
                        }


                        //Read XML data
                        string ModuleFile = "";
                        string ModuleID = "";
                        string FinalMessage = "";

                        while (xml.Read())
                        {

                            if (xml.Name == "ModuleFile")
                            {
                                ModuleFile = System.Text.Encoding.Unicode.GetString(Convert.FromBase64String(xml.ReadString()));
                            }

                            if (xml.Name == "ModuleID")
                            {
                                ModuleID = xml.ReadString();
                            }


                        }

                        if (MsgType == CM_ModuleLoadStarted)
                        {
                            FinalMessage = "Module loaded";
                        }
                        else if (MsgType == CM_ModuleUnloadStarted)
                        {
                            FinalMessage = "Module unloaded";
                        }


                        Grid.Rows.Add();
                        Grid.SetData(Grid.Rows.Count - 1, 1, FinalMessage);
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        Grid.Rows[Grid.Rows.Count - 1].Node.Level = 0;
                        Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Modules"];
                        Grid.SetCellImage(Grid.Rows.Count - 1, 1, KDT.Properties.Resources.Image_Modules);

                        //set row type
                        if (ModuleFile.Trim().Length != 0)
                        {
                            ExtraRowTag tag = new ExtraRowTag();
                            tag.ModulePath = ModuleFile;
                            tag.RowType = RowType.ModuleRow;
                            Grid.Rows[Grid.Rows.Count - 1].UserData = tag;
                        }



                        //module file name
                        Grid.Rows.Add();
                        Grid.SetData(Grid.Rows.Count - 1, 1, (ModuleFile.Trim().Length != 0 ? ModuleFile : ModuleID));
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;





                        //Break or Not ?
                        if (this.Tracer.TracingOptions.ModuleLoadedBreak)
                        {
                            try
                            {
                                Win32APIs.NtSuspendProcess(this.CurrentProcess.Handle);
                            }
                            catch (Exception ex)
                            {

                            }
                        }


                        break;
                    }


                case CM_JITCompilationStarted:
                    {


                        if (!this.Tracer.TracingOptions.EnterFunctionLog)
                        {
                            return;
                        }


                        string ModuleFile = "";
                        string ClassName = "";
                        string MethodName = "";
                        string MethodID = "";
                        string MethodToken = "";
                        string CFFIndex = "";


                        while (xml.Read())
                        {

                            if (xml.Name == "ModuleFile")
                            {
                                ModuleFile = System.Text.Encoding.Unicode.GetString(Convert.FromBase64String(xml.ReadString()));
                            }

                            if (xml.Name == "ClassName")
                            {
                                ClassName = System.Text.Encoding.Unicode.GetString(Convert.FromBase64String(xml.ReadString()));
                            }

                            if (xml.Name == "MethodName")
                            {
                                MethodName = System.Text.Encoding.Unicode.GetString(Convert.FromBase64String(xml.ReadString()));
                            }

                            if (xml.Name == "MethodID")
                            {
                                MethodID = xml.ReadString();
                            }

                            if (xml.Name == "MethodToken")
                            {
                                MethodToken = xml.ReadString();
                            }

                            if (xml.Name == "CFFIndex")
                            {
                                CFFIndex = xml.ReadString();
                            }


                        }

                        string finalmessage;

                        if (ModuleFile.Trim().Length != 0)
                        {
                            finalmessage = "[" + ModuleFile + "] " + "Function compiled";
                        }
                        else
                        {
                            finalmessage = "Function compiled";
                        }

                        Grid.Rows.Add();
                        Grid.SetData(Grid.Rows.Count - 1, 1, finalmessage);
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        Grid.Rows[Grid.Rows.Count - 1].Node.Level = 0;

                        Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Methods"];
                        Grid.SetCellImage(Grid.Rows.Count - 1, 1, KDT.Properties.Resources.PublicMethod);

                        //set row type
                        if (ClassName.Trim().Length != 0 & MethodName.Trim().Length != 0)
                        {
                            ExtraRowTag tag = new ExtraRowTag();
                            tag.MethodPath = ClassName + "." + MethodName;
                            tag.RowType = RowType.MethodRow;
                            Grid.Rows[Grid.Rows.Count - 1].UserData = tag;
                        }





                        if (MethodName.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, MethodName);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }

                        if (ModuleFile.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "Module : " + ModuleFile);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }

                        if (ClassName.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "Parent Class : " + ClassName);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                            Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Browsable"];
                            //set row type

                            ExtraRowTag tag = new ExtraRowTag();
                            tag.TypePath = ClassName;
                            tag.RowType = RowType.TypeRow;
                            Grid.Rows[Grid.Rows.Count - 1].UserData = tag;


                        }

                        if (MethodID.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "Method ID : " + MethodID);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }

                        if (MethodToken.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "Method Token : " + MethodToken);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }

                        if (CFFIndex.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "CFF explorer index : " + CFFIndex);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }


                        //Break or Not ?
                        if (this.Tracer.TracingOptions.EnterFunctionBreak)
                        {
                            try
                            {
                                Win32APIs.NtSuspendProcess(this.CurrentProcess.Handle);
                            }
                            catch (Exception ex)
                            {

                            }
                        }

                        break;
                    }


                case CM_ThreadCreated:
                case CM_ThreadDestroyed:
                    {

                        if (!this.Tracer.TracingOptions.ThreadCreatedLog)
                        {
                            return;
                        }


                        //Read XML data
                        string ThreadID = "";
                        string FinalMessage = "";

                        while (xml.Read())
                        {

                            if (xml.Name == "ThreadID")
                            {
                                ThreadID = xml.ReadString();
                            }

                        }

                        if (MsgType == CM_ThreadCreated)
                        {
                            FinalMessage = "Thread created : " + ThreadID;
                        }
                        else if (MsgType == CM_ThreadDestroyed)
                        {
                            FinalMessage = "Thread exited : " + ThreadID;
                        }



                        Grid.Rows.Add();
                        Grid.SetData(Grid.Rows.Count - 1, 1, FinalMessage);
                        Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Threads"];
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        Grid.Rows[Grid.Rows.Count - 1].Node.Level = 0;



                        if (MsgType == CM_ThreadCreated)
                        {
                            Grid.SetCellImage(Grid.Rows.Count - 1, 1, KDT.Properties.Resources.thread_start);
                        }
                        else if (MsgType == CM_ThreadDestroyed)
                        {
                            Grid.SetCellImage(Grid.Rows.Count - 1, 1, KDT.Properties.Resources.thread_end);
                        }


                        //Break or Not ?
                        if (this.Tracer.TracingOptions.ThreadCreatedBreak || this.Tracer.TracingOptions.ThreadDestroyedBreak)
                        {
                            try
                            {
                                Win32APIs.NtSuspendProcess(this.CurrentProcess.Handle);
                            }
                            catch (Exception ex)
                            {

                            }
                        }



                        break;
                    }




                case CM_ExceptionThrown:
                    {
                        if (!this.Tracer.TracingOptions.ExceptionThrownLog)
                        {
                            return;
                        }


                        //Read XML data
                        string ClassName = "";
                        string ClassID = "";
                        string MethodID = "";
                        string FinalMessage = "";


                        while (xml.Read())
                        {

                            if (xml.Name == "ClassName")
                            {
                                ClassName = System.Text.Encoding.Unicode.GetString(Convert.FromBase64String(xml.ReadString()));
                            }

                            //if (xml.Name == "ClassID")
                            //{
                            //    ClassID = xml.ReadString();
                            //}

                            //if (xml.Name == "MethodID")
                            //{
                            //    MethodID = xml.ReadString();
                            //}

                        }


                        FinalMessage = "Exception Thrown";

                        Grid.Rows.Add();
                        Grid.SetData(Grid.Rows.Count - 1, 1, FinalMessage);
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        Grid.Rows[Grid.Rows.Count - 1].Node.Level = 0;
                        Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Exceptions"];
                        Grid.SetCellImage(Grid.Rows.Count - 1, 1, KDT.Properties.Resources.exception);

                        if (ClassName.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "Exception type : " + ClassName);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }


                        //if (ClassID.Trim().Length != 0)
                        //{
                        //    Grid.Rows.Add();
                        //    Grid.SetData(Grid.Rows.Count - 1, 1, "Class ID : " + ClassID);
                        //    Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        //    Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        //}


                        //if (MethodID.Trim().Length != 0)
                        //{
                        //    Grid.Rows.Add();
                        //    Grid.SetData(Grid.Rows.Count - 1, 1, "MethodID ID : " + MethodID);
                        //    Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        //    Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        //}


                        //Break or Not ?
                        if (this.Tracer.TracingOptions.ExceptionThrownBreak)
                        {
                            try
                            {
                                Win32APIs.NtSuspendProcess(this.CurrentProcess.Handle);
                            }
                            catch (Exception ex)
                            {

                            }
                        }



                        break;
                    }


                case CM_ExceptionSearchFunctionEnter:
                    {

                        if (!this.Tracer.TracingOptions.ExceptionThrownLog)
                        {
                            return;
                        }



                        //Read XML data
                        string ClassName = "";
                        string MethodName = "";
                        string MethodID = "";
                        string FinalMessage = "";
                        string MethodToken = "";
                        string CFFIndex = "";

                        while (xml.Read())
                        {

                            if (xml.Name == "ClassName")
                            {
                                ClassName = System.Text.Encoding.Unicode.GetString(Convert.FromBase64String(xml.ReadString()));
                            }

                            if (xml.Name == "MethodName")
                            {
                                MethodName = System.Text.Encoding.Unicode.GetString(Convert.FromBase64String(xml.ReadString()));
                            }

                            if (xml.Name == "MethodToken")
                            {
                                MethodToken = xml.ReadString();
                            }

                            if (xml.Name == "CFFIndex")
                            {
                                CFFIndex = xml.ReadString();
                            }

                        }


                        FinalMessage = "Exception was thrown in method";


                        Grid.Rows.Add();
                        Grid.SetData(Grid.Rows.Count - 1, 1, FinalMessage);
                        Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        Grid.Rows[Grid.Rows.Count - 1].Node.Level = 0;
                        Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Exceptions"];
                        Grid.SetCellImage(Grid.Rows.Count - 1, 1, KDT.Properties.Resources.exception);
  

                        if (ClassName.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "Parent class : " + ClassName);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                            Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Browsable"];
                            //set row type

                            ExtraRowTag tag = new ExtraRowTag();
                            tag.TypePath = ClassName;
                            tag.RowType = RowType.TypeRow;
                            Grid.Rows[Grid.Rows.Count - 1].UserData = tag;

                        }

                        if (MethodName.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "method : " + MethodName);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;

                            //set row type
                            if (ClassName.Trim().Length != 0 & MethodName.Trim().Length != 0)
                            {
                                ExtraRowTag tag = new ExtraRowTag();
                                tag.MethodPath = ClassName + "." + MethodName;
                                tag.RowType = RowType.MethodRow;
                                Grid.Rows[Grid.Rows.Count - 1].UserData = tag;
                                Grid.Rows[Grid.Rows.Count - 1].Style = Grid.Styles["Browsable"];
                            }

                        }

                        if (MethodToken.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "Method Token : " + MethodToken);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }

                        if (CFFIndex.Trim().Length != 0)
                        {
                            Grid.Rows.Add();
                            Grid.SetData(Grid.Rows.Count - 1, 1, "CFF explorer index : " + CFFIndex);
                            Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                            Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        }



                        //if (MethodID.Trim().Length != 0)
                        //{
                        //    Grid.Rows.Add();
                        //    Grid.SetData(Grid.Rows.Count - 1, 1, "MethodID ID : " + MethodID);
                        //    Grid.Rows[Grid.Rows.Count - 1].IsNode = true;
                        //    Grid.Rows[Grid.Rows.Count - 1].Node.Level = 1;
                        //}


                        //Break or Not ?
                        if (this.Tracer.TracingOptions.ExceptionThrownBreak)
                        {
                            try
                            {
                                Win32APIs.NtSuspendProcess(this.CurrentProcess.Handle);
                            }
                            catch (Exception ex)
                            {

                            }
                        }



                        break;
                    }
            }

            xml.Close();

            //xmlbuffer.Dispose();


        }


        #endregion


        #region Update Tracer options



        //update log options
        //private void checkBox_AssemblyLoaded_log_Click(object sender, EventArgs e)
        //{

        //    if (this.Tracer != null)
        //    {
        //        this.Tracer.TracingOptions.AssemblyLoadedLog = checkBox_AssemblyLoaded_log.Checked;
        //    }

        //}


        private void checkBox_ModuleLoaded_Log_Click(object sender, EventArgs e)
        {
            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.ModuleLoadedLog = checkBox_ModuleLoaded_Log.Checked;
            }
        }


        private void checkBox_EnterFunction_Log_Click(object sender, EventArgs e)
        {

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.EnterFunctionLog = checkBox_EnterFunction_Log.Checked;
            }

        }

        private void checkBox_exceptionThrown_Log_Click(object sender, EventArgs e)
        {

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.ExceptionThrownLog = checkBox_exceptionThrown_Log.Checked;
            }

        }

        private void checkBox_threadCreated_Log_Click(object sender, EventArgs e)
        {

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.ThreadCreatedLog = checkBox_threadCreated_Log.Checked;
            }

        }



        //private void checkBox_thread_destroyed_Log_Click(object sender, EventArgs e)
        //{

        //    if (this.Tracer != null)
        //    {
        //        this.Tracer.TracingOptions.ThreadDestroyedLog = checkBox_thread_destroyed_Log.Checked;
        //    }

        //}


        //==========================================================================


        //private void checkBox_AssemblyLoaded_break_Click(object sender, EventArgs e)
        //{

        //    if (this.Tracer != null)
        //    {
        //        this.Tracer.TracingOptions.AssemblyLoadedBreak = checkBox_AssemblyLoaded_break.Checked;
        //    }

        //}

        private void checkBox_ModuleLoaded_break_Click(object sender, EventArgs e)
        {

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.ModuleLoadedBreak = checkBox_ModuleLoaded_break.Checked;
            }

        }

        private void checkBox_EnterFunction_break_Click(object sender, EventArgs e)
        {

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.EnterFunctionBreak = checkBox_EnterFunction_break.Checked;
            }

        }

        private void checkBox_exceptionThrown_break_Click(object sender, EventArgs e)
        {

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.ExceptionThrownBreak = checkBox_exceptionThrown_break.Checked;
            }

        }

        private void checkBox_threadCreated_break_Click(object sender, EventArgs e)
        {

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.ThreadCreatedBreak = checkBox_threadCreated_break.Checked;
            }

        }

        //private void checkBox_thread_destroyed_break_Click(object sender, EventArgs e)
        //{

        //    if (this.Tracer != null)
        //    {
        //        this.Tracer.TracingOptions.ThreadDestroyedBreak = checkBox_thread_destroyed_break.Checked;
        //    }

        //}


        private void toolStripButton_power_Click(object sender, EventArgs e)
        {

            if (toolStripButton_power.Checked)
            {
                toolStripButton_power.Image = KDT.Properties.Resources.power_on;
            }
            else
            {
                toolStripButton_power.Image = KDT.Properties.Resources.power_off;
            }

            if (this.Tracer != null)
            {
                this.Tracer.TracingOptions.Power = toolStripButton_power.Checked;
            }


        }


        #endregion


        //Restart
        private void toolStripButton_Restart_Click(object sender, EventArgs e)
        {

            //Terminate current process
            toolStripButton_Stop_Click(null, null);
            //Start Again
            toolStripButton_start_Click(null, null);

        }

        //Terminate process
        private void toolStripButton_Stop_Click(object sender, EventArgs e)
        {

            if ((this.CurrentProcess != null) && !this.CurrentProcess.HasExited)
            {
                try
                {
                    if (Win32APIs.TerminateProcess(this.CurrentProcess.Handle, 0))
                    {

                        //enable about button
                        this.toolStripButton_About.Enabled = true;

                        //enable save button
                        this.toolStripButton_Save.Enabled = true;

                        //enable start button
                        this.toolStrip1.Enabled = true;

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                //this.AboutToolStripMenuItem.Enabled = true;

                //this.SaveLogToolStripMenuItem.Enabled = true;

            }


        }

        //Resume current process
        private void toolStripButton_resume_Click(object sender, EventArgs e)
        {

            if ((this.CurrentProcess != null) && !this.CurrentProcess.HasExited)
            {
                try
                {
                    Win32APIs.NtResumeProcess(this.CurrentProcess.Handle);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        //Suspend current process
        private void toolStripButton_pause_Click(object sender, EventArgs e)
        {

            if ((this.CurrentProcess != null) && !this.CurrentProcess.HasExited)
            {
                try
                {
                    Win32APIs.NtSuspendProcess(this.CurrentProcess.Handle);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        //Save grid contents
        private void toolStripButton_Save_Click(object sender, EventArgs e)
        {



        }

        //Numbering and scrolling
        private void Grid_GridChanged(object sender, C1.Win.C1FlexGrid.GridChangedEventArgs e)
        {
            if (e.GridChangedType == C1.Win.C1FlexGrid.GridChangedTypeEnum.RowAdded)
            {

                Grid.SetData(Grid.Rows.Count - 1, 0, (Grid.Rows.Count - 1).ToString());

                if (toolStripButton_autoScroll.Checked)
                {
                    Grid.ShowCell(Grid.Rows.Count - 1, 0);
                }

            }
        }

        //Select file in Explorer
        private void SelectFile(string FilePath)
        {

            if (!File.Exists(FilePath))
            {
                return;
            }

            // combine the arguments together
            // it doesn't matter if there is a space after ','
            string argument = @"/select, " + FilePath;

            System.Diagnostics.Process.Start("explorer.exe", argument);

        }

        //Some double click
        private void Grid_DoubleClick(object sender, EventArgs e)
        {
            return;
            if (Grid.MouseCol != 1)
            {
                return;
            }

            if (Grid.MouseRow <= 0)
            {
                return;
            }

            if (Grid.Rows[Grid.MouseRow].UserData == null)
            {
                return;
            }

            ExtraRowTag tag = (ExtraRowTag)Grid.Rows[Grid.MouseRow].UserData;

            switch (tag.RowType)
            {
                case RowType.ModuleRow:

                    try
                    {

                        SelectFile(tag.ModulePath);

                    }
                    catch (Exception)
                    {


                    }

                    break;

                case RowType.MethodRow:


                    //RemoteControl.SelectMethodDeclaration("M:" + tag.MethodPath).ToString() ;

                    //new RemoteControl().SelectTypeDeclaration("T:" + tag.MethodPath);

                    new RemoteControl().SelectMethodDeclaration("M:" + tag.MethodPath);


                    break;

                case RowType.TypeRow:

                    new RemoteControl().SelectTypeDeclaration("T:" + tag.TypePath);


                    break;


            }

        }

        private void textFileToolStripMenuItem_Save_as_Text_Click(object sender, EventArgs e)
        {

            if (Grid.Rows.Count == 1)
            {
                MessageBox.Show("There is nothing to save now", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                using (SaveFileDialog CD = new SaveFileDialog())
                {
                    CD.Filter = "Text file(*.txt)|*.txt";
                    CD.AddExtension = true;
                    CD.ValidateNames = true;

                    UnHookME();

                    if (CD.ShowDialog() == DialogResult.OK)
                    {
                        Grid.SaveGrid(CD.FileName, C1.Win.C1FlexGrid.FileFormatEnum.TextComma, C1.Win.C1FlexGrid.FileFlags.None, System.Text.Encoding.UTF8);
                        Application.DoEvents();
                        MessageBox.Show("Results saved to \n\n" + CD.FileName, "KDT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    HookME();
                }


            }

        }

        private void ToolStripMenuItem_Save_as_excel_Click(object sender, EventArgs e)
        {

            if (Grid.Rows.Count == 1)
            {
                MessageBox.Show("There is nothing to save now", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                using (SaveFileDialog CD = new SaveFileDialog())
                {
                    CD.Filter = "Excel file(*.xls)|*.xls";
                    CD.AddExtension = true;
                    CD.ValidateNames = true;

                    UnHookME();

                    if (CD.ShowDialog() == DialogResult.OK)
                    {
                        Grid.SaveGrid(CD.FileName, C1.Win.C1FlexGrid.FileFormatEnum.Excel, C1.Win.C1FlexGrid.FileFlags.None, System.Text.Encoding.UTF8);
                        Application.DoEvents();
                        MessageBox.Show("Results saved to \n\n" + CD.FileName, "KDT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    HookME();
                }


            }

        }

        private void toolStripButton_About_Click(object sender, EventArgs e)
        {

            MessageBox.Show("dotNET tracer 2.2 for x64 bit\n\n" + "Coded by : Kurapica\n\n" + "https://b-at-s.info/", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //using (Form_About CD = new Form_About())
            //{
            //    CD.ShowDialog();
            //}

        }

        private void toolStrip1_DragDrop(object sender, DragEventArgs e)
        {

            try
            {

                if (e.Data.GetDataPresent(DataFormats.FileDrop))
                {

                    string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

                    toolStripTextBox_FileName.Text = files[0];
 
                }

            }
            catch (Exception)
            {
                
                
            }

        }

        private void toolStrip1_DragEnter(object sender, DragEventArgs e)
        {

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }

        }


    }
}
