﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace KDT
{
    public static class Win32APIs
    {



        [DllImport("user32", EntryPoint = "SetWindowLongPtrW", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int SetWindowLongPtr(IntPtr hwnd, int nIndex, WindowProcedure dwNewLong);

        [DllImport("user32", EntryPoint = "CallWindowProcW", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hwnd, uint Msg, int wParam, int lParam);

        [DllImport("user32", EntryPoint = "SetWindowLongPtrW", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int SetWindowLongEX(IntPtr hwnd, int nIndex, IntPtr dwNewLong);

        [DllImport("system.dll")]
        public static extern int DllRegisterServer();

        [DllImport("ntdll", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int NtResumeProcess(IntPtr ProcessHandle);

        [DllImport("ntdll", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int NtSuspendProcess(IntPtr ProcessHandle);

        [DllImport("kernel32", EntryPoint = "OutputDebugStringW", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern void OutputDebugString(IntPtr lpOutputString);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError = true)]
        static extern bool PostMessage(HandleRef hWnd, uint Msg, IntPtr wParam, IntPtr lParam);


        public delegate int WindowProcedure(IntPtr hwnd, int uMsg, int wParam, int lParam);



    }
}
