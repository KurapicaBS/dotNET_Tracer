﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Web;

namespace KDT
{
    public class RemoteControl
    {

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static  extern bool SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, ref COPYDATASTRUCT lParam);

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError = true)]
        public static  extern bool PostMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, ref COPYDATASTRUCT lParam);

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        public static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);

        private delegate bool EnumWindowsCallback(IntPtr hwnd, int lparam);

        [DllImport("user32.dll")]
        private static extern int EnumWindows(EnumWindowsCallback callback, int lparam);

        [DllImport("user32.dll")]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder title, int size);


        [StructLayout(LayoutKind.Sequential)]
        public struct COPYDATASTRUCT
        {
            public IntPtr Padding;
            public int Size;
            public IntPtr Buffer;
        }

        public string message;
        IntPtr targetWindow = IntPtr.Zero;

        public void SelectMethodDeclaration(string key)
        {
            message = "SelectMethodDeclaration\n" + key;
            System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(this.Send));
            thread.Start();

        }

        public void SelectTypeDeclaration(String key)
        {
            message = "SelectTypeDeclaration\n" + key;
            System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(this.Send));
            thread.Start();

        }

        public void Send(object data)
        {
            //IntPtr hWnd = FindWindow(null, "Lutz Roeder's .NET Reflector");
            //IntPtr hWnd = FindWindowByCaption(IntPtr.Zero, ".NET Reflector 7.3.0.18");

            // We can't use a simple FindWindow, because Reflector title 
            // can vary: we must detect its window title starts with a known value; 
            // not simply it is equal to a known value. See the EnumWindow method.
            EnumWindows(new EnumWindowsCallback(EnumWindow), 0);

            if (targetWindow != IntPtr.Zero)
            {
                byte[] source = System.Text.Encoding.Unicode.GetBytes(message);
                COPYDATASTRUCT lParam = new COPYDATASTRUCT();
                lParam.Padding = IntPtr.Zero;
                lParam.Size = source.Length;
                lParam.Buffer = Marshal.AllocHGlobal(lParam.Size);
                Marshal.Copy(source, 0, lParam.Buffer, source.Length);
                bool flag = SendMessage(targetWindow, 0x4a, IntPtr.Zero, ref lParam);
                Marshal.FreeHGlobal(lParam.Buffer);
                //return flag;
            }
            else
            {
                MessageBox.Show("Make sure that Reflector is opened and that target assembly is loaded into Reflector", "Reflector not detected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            //return false;
        }

        private bool EnumWindow(IntPtr handle, int lparam)
        {
            StringBuilder titleBuilder = new StringBuilder(256);
            GetWindowText(handle, titleBuilder, 256);

            if (titleBuilder.ToString().StartsWith("Lutz Roeder's .NET Reflector"))
                targetWindow = handle;

            if (titleBuilder.ToString().StartsWith("Red Gate's .NET Reflector"))
                targetWindow = handle;

            if (titleBuilder.ToString().StartsWith(".NET Reflector"))
                targetWindow = handle;

            return true;
        }	


    }
}
