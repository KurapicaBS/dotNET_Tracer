﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KDT
{
    public class Tracer
    {

        public Tracer(string filename, string ProcessArguments, TracerOptions options)
        {

            this.AssemblyFilename = filename;
            this.ProcessArguments = ProcessArguments;
            this.TracingOptions = options;


        }



        private string p_AssemblyFilename;
        public string AssemblyFilename
        {
            get { return p_AssemblyFilename; }
            private set { p_AssemblyFilename = value; }
        }


        private string p_ProcessArguments;
        public string ProcessArguments
        {
            get { return p_ProcessArguments; }
            private set { p_ProcessArguments = value; }
        }



        private TracerOptions p_TracerOptions;
        public TracerOptions TracingOptions
        {
            get { return p_TracerOptions; }
            set { p_TracerOptions = value; }
        }






    }
}
